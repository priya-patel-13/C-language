#include<stdio.h>
void main()
{
	int year;

	printf("enter your year:");
	scanf("%d",&year);

	if(year%=4)
	{
		printf("this year is leap year:");
	}
	else 
	{
		printf("this year is not leap year");
	}
}