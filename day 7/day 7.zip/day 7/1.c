#include<stdio.h>
void main()
{
	int a=8,b=3;

	if(a<b){
		printf("a is small");


	}
	else{
			printf("b is small");
		}

}