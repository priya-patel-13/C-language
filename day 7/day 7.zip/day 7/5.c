#include <stdio.h>
void main()
{
	int a;

	printf("enter your choice:");
	scanf("%d",&a);

	if(a%=2)
	{
		printf("a is even");
	}
	else
	{
		printf("a is odd");
	}

}