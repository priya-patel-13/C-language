#include <stdio.h>
void main()
{
	int a=8,b=3;

	if(a>b)
	{
		printf("a is max");

	}
	else{
		printf("b is max");
	}
}