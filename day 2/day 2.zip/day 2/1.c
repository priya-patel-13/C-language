#include<stdio.h>
main()
{
	printf("\n My Name is : PRIYA");
	printf("\n My Age is : 18");
	printf("\n My School Name is :P & B Oriantal");
}