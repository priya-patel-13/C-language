#include<stdio.h>
main(){
	printf("\n - - - - -");
	printf("\n | \t |");
	printf("\n R \t |");
	printf("\n N \t |");	
	printf("\n W \t |");
    printf("\n | \t |");
    printf("\n - - - - -");

}