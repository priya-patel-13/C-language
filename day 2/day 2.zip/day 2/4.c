#include <stdio.h>
main(){
	printf("*");
	printf("\n*");
	printf("\n*");
	printf("\n* \t * * \t   *");
	printf("\n*\t*   *     *");
	printf("\n*      *     *   *");
	printf("\n*     *       * *");
	printf("\n*    *");
	printf("\n*   *");
	printf("\n*  *");
	printf("\n* *");
	printf("\n*");
}