#include<stdio.h>
void main()
{
	int l=2;
	int a=l*4;

	printf("peramiter of l: %d",a);
}