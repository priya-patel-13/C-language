#include<stdio.h>
void main()

{
    float a , b, c, d ,perimeter;
    a= c= 5;
    b=d= 4;
    perimeter = 2*(a+b);
    printf(" Perimeter of Rectangle is : %f",perimeter);
}