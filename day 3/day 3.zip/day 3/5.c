#include <stdio.h>
void main()
{
	int a=5,b=5,c=10;
	int d=a+b+c;

	printf(" sum of three num: %d",d);

}