#include <stdio.h>
void main()
{
	int a=2,b=2,c=2,d=2;
	int e=a*b*c*d;

	printf(" sum of four num: %d",e);

}