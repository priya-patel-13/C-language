#include <stdio.h>
int main()
{
int width=5;
int length=10;
int area=width*length;
printf("Area of the rectangle=%d",area);
}