#include <stdio.h>
void main(){

	int a=5,b;
	b=a*a;

	printf(" squre of a: %d",b);
}