#include <stdio.h>
void main()
{
	int a=5,b=5;
	int c=a+b;

	printf(" sum of two num: %d",c);

}