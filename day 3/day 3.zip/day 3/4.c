#include <stdio.h>
void main()
{
	int a=25,b=5;
	int c=a/b;

	printf(" division of two num: %d",c);

}