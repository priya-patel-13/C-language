#include <stdio.h>
 
void main()
{
	float r,pie=3.14,c;

	printf("enter the value of r:");
	scanf("%f",&r);

	c=2*pie*r;

	printf("value of c=%f",c);

} 