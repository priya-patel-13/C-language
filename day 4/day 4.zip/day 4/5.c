#include <stdio.h>
void main()
{
	int a,b;

	printf("\nenter the value of a:");
	scanf("%d",&a);

	printf("\nenter the value of b:");
	scanf("%d",&b);

	printf("\n the ans is :%d ",a*b/2);

}