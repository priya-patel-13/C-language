#include<stdio.h>

void main()
{
  int hours,payment;
  	printf("\nEnter is value::");
	scanf("%d",&hours);
	   
	  payment=hours*15;
	  
	  printf("payment %d",payment); 


}