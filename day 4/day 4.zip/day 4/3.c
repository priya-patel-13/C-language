#include <stdio.h>
void main()
{
	int a,b;

	printf("\n enter the num of a:");
	scanf("%d",&a);
	printf("\n enter the num of b:");
	scanf("%d",&b);


	printf("\n product of num :%d",a*b);
}