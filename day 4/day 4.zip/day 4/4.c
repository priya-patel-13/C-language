#include <stdio.h>
void main()
{
	float pi=3.14159,r;

	printf("\nenter the num of r: ");
	scanf("%f",&r);

	printf("\n area of circle : %2f",pi*r*r);
}
