#include <stdio.h>
void main()
{
	int  a=5,b=3,c=7,d=2;

    printf("\n the ans is %d:",(a+b)*(c-d));
}