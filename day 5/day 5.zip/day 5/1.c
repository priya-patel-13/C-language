#include <stdio.h>
void main()
{
	int a=3,b=5;

	printf("\n total of two value: %d",a+b);

}