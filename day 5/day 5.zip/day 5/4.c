#include <stdio.h>
void main()
{
	int a=9;

	printf("\n squre of a:%d",a*a);
}