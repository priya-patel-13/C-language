#include <stdio.h>
void main()
{
	int d=50,t=10;

	printf("\n the answer is:%d",d/t);
}