#include <stdio.h>
void main(){

	int p,r,n;

	printf("\n enter the value of p:");
	scanf("%d",&p);
	printf("\n enter the value of r:");
	scanf("%d",&r);
	printf("\n enter the value of n:");
	scanf("%d",&n);

	printf("\n the ans is : %d",(p*r*n)/100);

}	