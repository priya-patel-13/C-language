#include <stdio.h>
void main()
{
	int a=10,b=20,c=30;
    
    printf("\n the Average of three num: %d",(a+b+c)/3);

}