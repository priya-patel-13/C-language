#include <stdio.h>
void main()
{
	int a=6,b=4;

	printf("\n multiplication of two num: %d",a*b);
}