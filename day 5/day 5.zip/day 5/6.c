#include<stdio.h>
void main()
{
	int a=2;

	printf("\n the cube of a: %d",a*a*a);
}